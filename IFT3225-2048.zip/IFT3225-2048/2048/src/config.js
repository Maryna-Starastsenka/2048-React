const gameParams = {
    rowCount: 4,
    colCount: 4,
}