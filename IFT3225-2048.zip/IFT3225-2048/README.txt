Maryna Starastsenka 
20166402



Rapport :

http://www-ens.iro.umontreal.ca/~starastm/2048-game/Rapport/Rapport-tp2.xhtml



Code déployé sur le serveur :

http://www-ens.iro.umontreal.ca/~starastm/2048-game/2048/index.xhtml