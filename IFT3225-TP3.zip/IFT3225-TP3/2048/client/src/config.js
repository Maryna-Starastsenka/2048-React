const gameParams = {
    rowCount: 4,
    colCount: 4,
}

const baseUrl = 'https://www-ens.iro.umontreal.ca/~starastm/cgi-bin/init.cgi/'