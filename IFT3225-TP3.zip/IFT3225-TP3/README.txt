Maryna Starastsenka 
20166402



Rapport :

http://www-ens.iro.umontreal.ca/~starastm/ift3225/tp3/Rapport/Rapport-tp3.xhtml



Code déployé sur le serveur :

http://www-ens.iro.umontreal.ca/~starastm/ift3225/tp3/client/index.xhtml